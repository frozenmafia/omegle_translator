Select your language and the language in which you want to translate.

language will be translated irrespective of the stranger's language.

'Type 'exit()' to exit the chat.'
'Type 'change()' to change the language.'
'Type 'change(a,b)',where 'a' means user lang code and 'b' means stranger lang code '
'Type 'kill()' to exit the chat.'
